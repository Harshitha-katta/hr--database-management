INSERT INTO department (dept_name) VALUES ('HR'), ('Finance'), ('IT');

INSERT INTO employee (emp_name, dept_id, salary) VALUES
('Harshitha', 1, 50000),
('Rohit', 2, 60000),
('Anjali', 3, 55000);
