import mysql.connector

class Department:
    @staticmethod
    def add_department(db):
        name = input("Enter department name: ")
        cursor = db.cursor()
        cursor.execute("INSERT INTO department (dept_name) VALUES (%s)", (name,))
        db.commit()
        print("Department added!")

    @staticmethod
    def view_departments(db):
        cursor = db.cursor()
        cursor.execute("SELECT * FROM department")
        for row in cursor.fetchall():
            print(row)

class Employee:
    @staticmethod
    def add_employee(db):
        name = input("Enter employee name: ")
        dept_id = int(input("Enter department ID: "))
        salary = float(input("Enter salary: "))
        cursor = db.cursor()
        cursor.execute(
            "INSERT INTO employee (emp_name, dept_id, salary) VALUES (%s, %s, %s)",
            (name, dept_id, salary)
        )
        db.commit()
        print("Employee added!")

    @staticmethod
    def view_employees(db):
        cursor = db.cursor()
        cursor.execute("SELECT * FROM employee")
        for row in cursor.fetchall():
            print(row)

class Attendance:
    pass
