# HR Database Management System

## Description
This project manages HR data including employees, departments, and attendance using Python and SQL.

## Features
- Add, update, delete employee records
- View department-wise employee data
- Track employee attendance
- Search employees by ID or name

## Requirements
- Python 3.x
- MySQL / SQLite
- Libraries: `sqlite3` (for SQLite) or `mysql-connector-python` (for MySQL)

## Setup
1. Create the database using `database.sql`.
2. Install required Python packages:
   ```
   pip install -r requirements.txt
   ```
3. Run the project:
   ```
   python main.py
   ```
