CREATE DATABASE hr_management;
USE hr_management;

CREATE TABLE department (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(50) NOT NULL
);

CREATE TABLE employee (
    emp_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_name VARCHAR(50) NOT NULL,
    dept_id INT,
    joining_date DATE,
    salary DECIMAL(10,2),
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE attendance (
    att_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_id INT,
    att_date DATE,
    status VARCHAR(10),
    FOREIGN KEY (emp_id) REFERENCES employee(emp_id)
);
