from models import Employee, Department, Attendance
from utils import connect_db

def menu():
    print("1. Add Employee")
    print("2. View Employees")
    print("3. Add Department")
    print("4. View Departments")
    print("5. Exit")
    return input("Enter choice: ")

def main():
    db = connect_db()
    while True:
        choice = menu()
        if choice == "1":
            Employee.add_employee(db)
        elif choice == "2":
            Employee.view_employees(db)
        elif choice == "3":
            Department.add_department(db)
        elif choice == "4":
            Department.view_departments(db)
        elif choice == "5":
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()
